package Main;

import Model.Estoque;
import Model.Gerente;
import java.math.BigDecimal;

public class Main {

    public static void main(String[] args) {

        Gerente gerente = new Gerente("joao");
        
        Estoque estoque = new Estoque("camisa", new BigDecimal("1000"), new BigDecimal(10));
        estoque.anexar(gerente);
        estoque.setValor(new BigDecimal("10000"));
    }
}
