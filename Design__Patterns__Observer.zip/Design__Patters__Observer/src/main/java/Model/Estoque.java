package Model;

import Observer.Observer;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Estoque {

    private String produto;
    private BigDecimal valor;
    private BigDecimal desconto;

    //ArrayList de interfaces observer
    private List<Observer> observers = new ArrayList<Observer>();

    public Estoque() {
    }

    public Estoque(String produto, BigDecimal valor, BigDecimal desconto) {
        this.produto = produto;
        this.valor = valor;
        this.desconto = desconto;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
        notificacaoObjeto();
    }

    public BigDecimal getDesconto() {
        return desconto;
    }

    public void setDesconto(BigDecimal desconto) {
        this.desconto = desconto;
    }

    //metodo que vai receber um objeto do tipo Observer que e uma interface 
    //apos isso ele vai pegar e adcionar esse objeto recebido em uma lista
    // essa lista so recebe objetos do tipo Observer que e uma interface
    public void anexar(Observer observer) {
        observers.add(observer);
    }
    
        public void notificacaoObjeto(){
        for(Observer observer : observers){
            observer.update(this);
        }
    }

}
