package Observer;

import Model.Estoque;

public interface Observer {

    public void update(Estoque estoque);

}
